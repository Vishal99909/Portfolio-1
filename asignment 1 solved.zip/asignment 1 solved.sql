CREATE DATABASE PEOPLE_EDUCATION;

SHOW DATABASES;
USE people_education;



USE people_educatio;
SHOW TABLES;
 
USE people_education; 
  CREATE TABLE people_info
 (name varchar(255),
 age INT,
 high_school_attended VARCHAR(255),
 height varchar(255));
 
 use people_education;
 CREATE TABLE school_info
(school_name varchar(255),
zip_code int);

use people_education;
CREATE TABLE school_mascot(
school_name varchar(255),
school_mascot varchar(255));


use people_education;
SHOW TABLES;



DROP TABLE school_mascot;



USE people_education;
INSERT INTO people_info
(name,age,high_school_attended,height)
VALUES
("ajay",26,"vidyaniketan","5m"),
("vijay",26,"vidyaniketan","7m"),
("nagesh",27,"vidyaniketan","6m"),
("haresh",26,"vidyaniketan","6m");


SELECT * from people_info;



---

INSERT INTO school_info
(school_name,zip_code)
VALUES
('vidyaniketan',400606),
('vidyaniketab',400606),
('little_flower',700303),
('vidya',400606);


---


SELECT * FROM school_info;