USE hero;
SELECT * FROM hero_battles;

SELECT COUNT(*) FROM hero_battles;


SELECT MAX(MyUnknownColumn) AS 'MAX',MIN(num_enemies) AS 'MIN' FROM hero_battles;
SELECT MAX(num_enemies) AS 'MAX',MIN(MyUnknownColumn) AS 'MIN' FROM hero_battles;

SELECT SUM(num_enemies),AVG(num_enemies) FROM hero_battles;

SELECT MIN(MyUnknownColumn) AS 'MIN' FROM hero_battles;
SELECT MAX(num_enemies) FROM hero_battles;
SELECT MAX(MyUnknownColumn) FROM hero_battles;
SELECT MIN(num_enemies) FROM hero_battles;


SELECT name ,SUM(num_enemies) AS total_enemies,
 AVG(num_enemies) AS avg_enemies FROM hero_battles
 GROUP BY name;
 
 
 SELECT name ,SUM(num_enemies) AS total_enemies,
 AVG(num_enemies) AS avg_enemies FROM hero_battles
 GROUP BY name
 ORDER BY AVG(num_enemies);
