USE hero;
SELECT * FROM hero_battles;

SELECT * FROM hero_battles
ORDER BY num_enemies;

SELECT * FROM hero_battles
ORDER BY num_enemies DESC;


SELECT name FROM hero_battles
WHERE name = 'Batman';

SELECT name FROM hero_battles
WHERE NOT name = 'Batman';

SELECT name,date,num_enemies,outcome FROM hero_battles
WHERE num_enemies = 1 AND 2;

SELECT name,date,num_enemies,outcome FROM hero_battles
WHERE num_enemies IN (1,2,10,12) ;

SELECT name,date,num_enemies,outcome FROM hero_battles
WHERE num_enemies = 1 OR 2;

SELECT name FROM hero_battles
WHERE name LIKE'%man'; 
